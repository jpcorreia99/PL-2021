import sys 


if len(sys.argv) == 1:
	input_file_path = "input/data.csv"
	output_file_path = f"output/data.json"
elif len(sys.argv) == 2: 
	input_file_path = f"input/{sys.argv[1]}"
	output_file_path = f"output/data.json"
elif len(sys.argv) == 3:
	input_file_path = f"input/{sys.argv[1]}"
	output_file_path = f"output/{sys.argv[2]}"
else:
	raise ValueError("Wrong number of arguments.\nUsage: python main.py [input_file_name] [output_file_name]")


# Reading the file
file = open(input_file_path)
lines = file.read().splitlines()  # splitlines to remove \n
file.close()

if len(lines) < 2:
	raise Exception("Insufficient lines in csv")

# Processing the file
start = time.time()
field_delimiter, operations_separator, csv_column_names, csv_column_operations = process_header(lines[0])
json_txt = convert_to_json(lines[1:],field_delimiter, operations_separator,csv_column_names, csv_column_operations)
end = time.time()

# Writing to json
output_file = open(output_file_path, "w")
output_file.write(json_txt)
output_file.close()

print(f"Time spent processing the csv: {end - start}s")