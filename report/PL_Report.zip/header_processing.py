import re
from typing import List

def process_header(header_line: str) -> (str, str, List[str], List[str]):
	"""Retrieves information about the fields declared in the header

	Args:
		header_line (str): First line of the csv file

	Raises:
		NameError: Unsupported operation is found in the header

	Returns:
		str: field delimiter 
		str: character separating group operations, 
		List(str): List of the names of each column,
		List(str): List where each index corresponds to the type of operation to be applied to the corresponding column by index
	"""

	column_names = []
	column_operations = []
	supported_group_operations = ["group", "sum", "avg", "max", "min"]
	field_delimiter = re.match(r'?:[^+*;,]+(?:\*|\+)?(?:[^;,]+)?(;|,|(placeholder for EOL))',header_line).group(1)

	if field_delimiter == ';':
		operations_separator = ","
		captures = re.findall(r'([^+*;]+)(\*|\+)?([^;]+)?', header_line);
	else:
		field_delimiter = "," # needs to be set as ',' since (placeholder for EOL) will break the program when processing the body 
		operations_separator = ";"
		captures = re.findall(r'([^+*,]+)(\*|\+)?([^,]+)?', header_line);

	for capture in captures:
		num_clauses = len(list(filter(None, capture)))
		column_names.append(capture[0])
		if num_clauses == 1:
			column_operations.append("none")
		elif num_clauses == 2:
			if capture[1] == "*":
				column_operations.append(["group"])
			elif capture[1] == "+":
				column_operations.append("cast")
		else:  # num_clauses == 3
			operations = [operation.lower() for operation in capture[2].split(operations_separator)]
			if any([operation not in supported_group_operations for operation in operations]):
				raise NameError("Unsupported Operation in header")
			else:
				column_operations.append(operations)

	return field_delimiter, operations_separator,column_names, column_operations