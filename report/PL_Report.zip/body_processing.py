import re
from typing import List

def convert_to_json(csv_lines: List[str],
				 field_delimiter: str,
				 operations_separator: str,
				 column_names: List[str],
				 column_operations: List[str]) -> str:
	"""Processes each line of the body of the csv and converts it to a string in json format

	Args:
		csv_lines (List[str]): Each line of the csv
		column_names (List[str]): List of the names of each column
		spcolumn_operations (List[str]): List where each index corresponds to the type of operation
		to be applied to the corresponding column by index

	Raises:
		AttributeError: If there's a row with a different number of columns than defined by the header
		AttributeError: If a row contains an empty or missing parenthesis on a group column
		ValueError: If a row contains non-numeric values on a group column
		ValueError: If a row with a cast operation contains non-numeric values

	Returns:
		str: String containing the complete JSON file
	"""
	string_list = []

	string_list.append("[")
	for i, line in enumerate(csv_lines):
		string_list.append("\t{")
		fields = line.split(field_delimiter)

		if len(fields) != len(column_names):
			raise AttributeError(
				f"Row {str(i + 2)} does not have the same number of columns as determined by the header")

		for j, field in enumerate(fields):
			if field: # skips empty fields
				if column_operations[j] == "none":
					string_list.append(f'\t\t"{column_names[j]}": "{field}"' +
						("," if (len(list(filter(None,fields[j:]))) > 1) else "")) # condition checks if it's not the last non-empty field   
				elif column_operations[j]== "cast":
					try:
						numeric_value = float(field)
						string_list.append(f'\t\t"{column_names[j]}": {numeric_value}' +
						("," if (len(list(filter(None,fields[j:]))) > 1) else "")) 
					except ValueError:
						raise ValueError(f"Row {str(i + 2)}: {field} can't be casted to a numeric value")
				else:
					values = re.match(r'\((.+?)\)', field)  # extract the values inside the parenthesis, since it's a list column
					if not values:
						raise AttributeError(f"Row {str(i + 2)} group column has incorrect format")

					values = values.group(1).split(operations_separator)

					if len(values) > 0:
						string_list = string_list + process_operations(column_names[j], values, column_operations[j],i + 2, len(list(filter(None,fields[j:]))) == 1) # boolean indicating it's the last column of the line
		if(i == len(csv_lines)-1):
			string_list.append("\t}") # the last object doest not have a comma
		else:
			string_list.append("\t},")
			
	string_list.append("]")
	return '\n'.join(string_list)


def process_operations(column_name: str,
					  values: List[str],
					  operations: List[str],
					  row_number: int,
					  last_column: bool) -> List[str]:

	""" Converts line portion corresponding to an operations column to it's json conterpart

	Args:
		column_name (str): Name of the column being processed,
		values (List[str]): list of values present in said column,
		operations (List[str]): list of operations to be applied to the values in the values list, matched by index,
		row_number (int): number of row being processed, useful for throwing informative exceptions
		last_column (boolean): flag indicating if it's the last non-empty column \
                                of the row being currently processed, for comma purposes

	Raises:
		ValueError:  If there's non-numeric values on a list of values

	Returns:
		List[str]: Json portion relative to the operations in the given collumn
	"""
	operation_results = []
	try:
		numeric_values = [float(value) for value in values]
		for i, operation in enumerate(operations):
			if operation == "group":
				operation_result = f'\t\t"{column_name}": {numeric_values}'
			if operation == "avg":
				operation_result = f'\t\t"{column_name}_avg": {sum(numeric_values)/len(numeric_values)}'
			elif operation == "sum":
				operation_result = f'\t\t"{column_name}_sum": {sum(numeric_values)}'
			elif operation == "min":
				operation_result = f'\t\t"{column_name}_min": {min(numeric_values)}'
			elif operation == "max":
				operation_result = f'\t\t"{column_name}_max": {max(numeric_values)}'
				
			operation_results.append(operation_result +
			 ("" if last_column and i==len(operations)-1 else ",")) #also checks if it's the last operation of the given column

		return operation_results
	except ValueError:
		raise ValueError(f"Non numeric element in row {str(row_number)} in a column that demands such");
